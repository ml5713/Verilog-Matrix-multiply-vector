#ifndef INNER_PRODUCT
#define INNER_PRODUCT

double inner_product(double *, double *, int);

#endif
